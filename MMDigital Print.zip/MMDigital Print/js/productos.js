const productos = 
    [
        {
            id: "producto-01",
            titulo: "Abre huecos",
            imagen: "./img/escolares/abre_huecos.webp",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 1.49,
    
        },
        {
            id: "producto-02",
            titulo: "Cartuchera",
            imagen: "./img/escolares/cartuchera.jpg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 3.99,
        },
        {
            id: "producto-03",
            titulo: "Resaltadores",
            imagen: "./img/escolares/resaltadores.webp",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 2.47,
        },
        {
            id: "producto-04",
            titulo: "Saca puntas",
            imagen: "./img/escolares/sacapuntas.webp",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 0.49,
        },
        {
            id: "producto-05",
            titulo: "Marcadores",
            imagen: "./img/escolares/marcadores.webp",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 2.99,
        },
        {
            id: "producto-06",
            titulo: "Caja de lápices mecánicos",
            imagen: "./img/escolares/lapiz_mecanico.jpg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 3.69,
        },
        {
            id: "producto-07",
            titulo: "Minas Staedler",
            imagen: "./img/escolares/minas_0.7.jpg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 0.99,
        },
        {
            id: "producto-08",
            titulo: "Borrador Staedler",
            imagen: "./img/escolares/borrador.jpg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 0.49,
        },
        {
            id: "producto-09",
            titulo: "Caja de lápices mongol de 12 piezas",
            imagen: "./img/escolares/lapices.gif",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 3.14,
        },
        {
            id: "producto-10",
            titulo: "Lápices de colores Faber-castell de 12 piezas",
            imagen: "./img/escolares/lapices_colores_12.webp",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 2.50,
        },
        {
            id: "producto-11",
            titulo: "Lápices de colores Faber-castell de 24 piezas",
            imagen: "./img/escolares/lapices_colores_24.webp",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 5.00,
        },
        {
            id: "producto-12",
            titulo: "Lápices de colores Faber-castell de 48 piezas",
            imagen: "./img/escolares/lapices_colores_48.jpg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 7.99,
        },
        {
            id: "producto-13",
            titulo: "Hojas blancas Ultrapaper de 500 hojas",
            imagen: "./img/escolares/hojas_blanca.jpg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 5.99,
        },
        {
            id: "producto-14",
            titulo: "Hojas de rayas Starmate con huecos de 250 hojas",
            imagen: "./img/escolares/hojas-rayas.jpg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 3.99,
        },
        {
            id: "producto-15",
            titulo: "Engrapadora Studmark",
            imagen: "./img/escolares/engrapadora_g.jpeg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 2.99,
        },
        {
            id: "producto-16",
            titulo: "Mini engrapadora Studmark con 600 grapas",
            imagen: "./img/escolares/engrapadora_p.jpeg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 2.05,
        },
        {
            id: "producto-17",
            titulo: "Caja de grapas",
            imagen: "./img/escolares/grapas.jpg",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 4.00,
        },
        {
            id: "producto-18",
            titulo: "Juego de geometría",
            imagen: "./img/escolares/juego_geometrico.webp",
            categoria: {
                nombre: "Escolares",
                id: "escolares",
            },
            precio: 1.60,
        },
        {
            id: "producto-19",
            titulo: "Cinta adhesiva",
            imagen: "./img/papeleria/cinta_adhesiva.webp",
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 2.19,
        },
        {
            id: "producto-20",
            titulo: "Tijeras",
            imagen: "./img/papeleria/tijera.webp",
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 2.19,
        },
        {
            id: "producto-21",
            titulo: "Acrílicos",
            imagen: "./img/papeleria/acrilicos.webp",
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 5.99,
        },
        {
            id: "producto-22",
            titulo: "Hojas de colores eurocolors",
            imagen: "./img/papeleria/hojas_colores.jpeg",
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 1.25,
        },
        {
            id: "producto-23",
            titulo: "Quitagrapas",
            imagen: "./img/papeleria/gitagrapas.jpg", 
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 1.99,
        },
        {
            id: "producto-24",
            titulo: "Goma Pritt grande",
            imagen: "./img/papeleria/goma_grande.jpeg",
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 2.99,
        },
        {
            id: "producto-25",
            titulo: "Goma Pritt barra",
            imagen: "./img/papeleria/goma_barra.jpg",
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 2.49,
        },
        {
            id: "producto-26",
            titulo: "Goma Prtt pequeña",
            imagen: "./img/papeleria/goma_chica.png",
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 1.49,
        },
        {
            id: "producto-27",
            titulo: "Caja de clips Studmark de 100 piezas",
            imagen: "./img/papeleria/caja_clips.jpeg",
            categoria: {
                nombre: "Papelería",
                id: "papeleria",
            },
            precio: 1.49,
        }
    ];

    const contenedorProductos = document.querySelector("#contenedor-productos");
    const botonesCategorias = document.querySelectorAll(".boton-categoria");
    const tituloPrincipal = document.querySelector("#titulo-principal");
    let botonesAgregar = document.querySelectorAll(".producto-agregar");
    const numerito = document.querySelector("#numerito");
    
    
    function cargarProductos(productosElegidos) {
    
        contenedorProductos.innerHTML = "";
    
        productosElegidos.forEach(producto => {
    
            const div = document.createElement("div");
            div.classList.add("producto");
            div.innerHTML = `
                <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
                <div class="producto-detalles">
                    <h3 class="producto-titulo">${producto.titulo}</h3>
                    <p class="producto-precio">$${producto.precio}</p>
                    <button class="producto-agregar" id="${producto.id}">Agregar</button>
                </div>
            `;
    
            contenedorProductos.append(div);
        })
    
        actualizarBotonesAgregar();
    }
    
    cargarProductos(productos); //Llamar con el arreglo 'productos'
    
    botonesCategorias.forEach(boton => {
        boton.addEventListener("click", (e) => {
    
            botonesCategorias.forEach(boton => boton.classList.remove("active"));
            e.currentTarget.classList.add("active");
    
            if (e.currentTarget.id != "todos") {
                const productoCategoria = productos.find(producto => producto.categoria.id === e.currentTarget.id);
                tituloPrincipal.innerText = productoCategoria.categoria.nombre;
                const productosBoton = productos.filter(producto => producto.categoria.id === e.currentTarget.id);
                cargarProductos(productosBoton);
            } else {
                tituloPrincipal.innerText = "Todos los productos";
                cargarProductos(productos);
            }
    
        })
    });
    
    function actualizarBotonesAgregar() {
        botonesAgregar = document.querySelectorAll(".producto-agregar");
    
        botonesAgregar.forEach(boton => {
            boton.addEventListener("click", agregarAlCarrito);
        });
    }

    let productosEnCarrito;

    let productosEnCarritoLS = localStorage.getItem("productos-en-carrito");
    /*const productosEnCarritoLS = JSON.parse(localStorage.getItem("productos-en-carrito"));*/

    if (productosEnCarritoLS){
        productosEnCarrito = JSON.parse(productosEnCarritoLS);
        actualizarNumerito();
    } else {
        productosEnCarrito = [];
    }

    /*const productosEnCarrito = [];*/
    
    function agregarAlCarrito(e) {
        const idBoton = e.currentTarget.id; 
        const productoAgregado = productos.find(producto => producto.id === idBoton); 
        
        if (productosEnCarrito.some(producto => producto.id === idBoton)) {

            const index = productosEnCarrito.findIndex(producto => producto.id === idBoton);
            productosEnCarrito[index].cantidad++;
            
        } else {
            productoAgregado.cantidad = 1;
            productosEnCarrito.push(productoAgregado);
        }

        actualizarNumerito();

        localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
    }
    
    function actualizarNumerito() {
        let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0); 
        numerito.innerText = nuevoNumerito;
    }